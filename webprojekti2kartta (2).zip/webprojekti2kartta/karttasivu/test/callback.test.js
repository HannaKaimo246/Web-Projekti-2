const {conn} = require('../routes/db.js');

test('Testing Call Back With Error', async (done) => {

  conn('http://localhost:3000/', async (err) => {

    expect(err).toEqual(Error("url is wrong"));
    done();
  })
});

test('Should return data', async (done) => {

  conn('http://localhost:3000/', async (err, data) => {

    expect(data).toStrictEqual('test');
    done();
  })
});