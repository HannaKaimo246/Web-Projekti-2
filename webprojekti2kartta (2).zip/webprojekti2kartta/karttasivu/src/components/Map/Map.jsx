import React, {useEffect, useState} from 'react';
import GoogleMapReact from 'google-map-react';
import {Paper, Typography, useMediaQuery} from '@material-ui/core';
import LocationOnOutlinedIcon from '@material-ui/icons/LocationOnOutlined';
import Rating from '@material-ui/lab/Rating';
import {Marker} from '@react-google-maps/api';

import useStyles from './styles';
import Input from '@material-ui/core/Input';
import Button from '@material-ui/core/Button';
import noteService from './notes';

const Location = ({text}: any) => <h3>{text}</h3>;

const Map = ({setCoordinates, setBounds, coordinates, places, markers, setMarkers})=> {
const classes = useStyles();
const isDesktop = useMediaQuery('(min-width:600px)');
const [user, setUser] = useState('');
const [users, setUsers] = useState([]);


  const handleChange = (event) => {

    event.preventDefault();

    setUser(event.target.value);

  }

  const addPerson = (event) => {
    event.preventDefault()
    const noteObject = {
      name: user,
    }

    noteService.create(noteObject).then(returnedNote => {
      setUsers(users.concat(returnedNote))
      setUser('')
    })

  }

  return (
     <div className={classes.mapContainer}>
       <Input type="text" placeholder="nimimerkki" id="nimimerkki" value={user} onChange={handleChange}>
       </Input>
       <Button class="btn btn-primary" type="submit" id="locationButton" onClick={addPerson}>
         Lisää
       </Button>
       <GoogleMapReact
           bootstrapURLKeys={{ key:'AIzaSyDkaIAq2l6wA4bJYafEwzPCREl8ZG8O6XY'}}
       defaultCenter={coordinates}
       center={coordinates}
       defaultZoom= {14}
       margin={[50,50,50,50]}
       options={''}
       onChange={(e) => {
       setCoordinates({lat: e.center.lat, lng: e.center.lng});
       setBounds({ ne: e.marginBounds.ne, sw: e.marginBounds.sw});
       }}
           onClick ={(event) => {
             setMarkers(current => [
                 ...current,
               {
                 lat: event.latLng.lat(),
                 lng: event.latLng.lng(),
                 time: new Date(),
               },
             ]);
           }}
         >
         {places?.map((place, i) => (
             <div
                 className={classes.markerContainer}
                 lat={Number(place.latitude)}
                 lng={Number(place.longitude)}
                 key={i}
             >  {
               !isDesktop ? (
                   <LocationOnOutlinedIcon color="primary" fontSize="large" />
                   ) : (
                       <Paper elevation={3} className={classes.paper}>
                          <Typography className={classes.typography} gutterBottom>
                            {place.name}
                          </Typography>
                         <Rating size="small" value={Number(place.rating)} readOnly />
                       </Paper>
               )}
             </div>
             ))}
         {markers.map((marker) => (
             <Marker
                 key={marker.time.toISOString()}
           position={{lat: marker.lat, lng: marker.lng}}
                 icon = {{
                   url: '/food.png',
                   scaledSize: new window.google.maps.Size(20,20),
                   origin: new window.google.maps.Point(0,0),
                   anchor: new window.google.maps.Point(10,10)
                 }}
             />
             ))}
         <Location
             lat={60.1864116}
             lng={24.9432801}
             text= 'Hanna Kaimo'
         />
       </GoogleMapReact>
           </div>
       )
}

export default Map;